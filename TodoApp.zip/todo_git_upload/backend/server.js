console.log("🛠 Server.js loaded...");
const express = require('express');
const cors = require('cors');
const fs = require('fs');
const app = express();
const PORT = 3000;
const DATA_FILE = __dirname + '/data.json';

app.use(cors());
app.use(express.json());

function loadTodos() {
try {
const data = fs.readFileSync(DATA_FILE, 'utf8');
return JSON.parse(data);
} catch (err) {
console.error('Failed to read data.json:', err);
return [];
}
}

function saveTodos(todos) {
fs.writeFileSync(DATA_FILE, JSON.stringify(todos, null, 2));
}

// Routes
app.get('/todos', (req, res) => {
const todos = loadTodos();
res.json(todos);
});

app.post('/todos', (req, res) => {
const todos = loadTodos();
const newTodo = {
id: Date.now().toString(),
task: req.body.task,
completed: false,
date: req.body.date
};
todos.push(newTodo);
saveTodos(todos);
res.json(newTodo);
});

app.put('/todos/:id', (req, res) => {
let todos = loadTodos();
const index = todos.findIndex(t => t.id === req.params.id);
if (index !== -1) {
todos[index] = { ...todos[index], ...req.body };
saveTodos(todos);
res.json(todos[index]);
} else {
res.status(404).json({ error: 'Not found' });
}
});

app.delete('/todos/:id', (req, res) => {
let todos = loadTodos();
todos = todos.filter(t => t.id !== req.params.id);
saveTodos(todos);
res.json({ success: true });
});

app.listen(PORT, () => {
console.log(`🚀 Server is running at http://localhost:${PORT}`);
});